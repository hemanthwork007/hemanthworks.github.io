# Tunis Personal Portfolio React Template

## Description

Setup Procedure

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run start
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration (vue-cli)

See [Configuration Reference](https://cli.vuejs.org/config/).
